package spring.main;

import spring.dao.AccountDaoImpl;
import spring.exception.InsufficientFundException;

public class Wallet {

	private static org.springframework.context.ApplicationContext context;
	static spring.dao.AccountDao accountDao;

	static java.util.Scanner in = new java.util.Scanner(System.in);

	public static void main(String[] args) throws InsufficientFundException {

		context = new org.springframework.context.support.ClassPathXmlApplicationContext("applicationContext.xml");
		accountDao = (spring.dao.AccountDao) context.getBean("accountDao");
		while (true) {
			sop("1. Create Wallet Account");

			sop("2. Get All Wallet Accounts");
			sop("3. Get Account By Wallet ID");
			sop("4. Update Wallet Account");
			sop("5. Delete Wallet Account");
			sop("0. Exit\n");
			sop(" Enter your choice");
			int choice = in.nextInt();
			in.nextLine();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				getAllAccounts();
				break;
			case 3:
				getAccountById();
				break;
			case 4:
				updateAccount();
				break;
			case 5:
				removeAccount();
				break;
			case 0:
				System.exit(0);
				break;
			default:
				sop("invalid choice");
			}
		}

	}

	private static void createAccount() throws InsufficientFundException  {
		sop("User Id: ");
		String id = in.nextLine();
		sop("User Name?");
		String name = in.nextLine();
		sop("Account Balance");
		double balance = in.nextDouble();

		int status = accountDao.createAccount(name, id, balance, generatePin());
	}

	private static void removeAccount() {
		/*
		 * sop("id?"); String id = in.nextLine(); try {
		 * sop(accountDao.getAccountById(id) + "\n");
		 * sop("do you wish to delete this record [Y/N] ?"); char choice =
		 * in.next().charAt(0); if (choice == 'y' || choice == 'Y') {
		 * 
		 * if (accountDao.removeAccount(id) == 1) {
		 * sop("account updated succesfully \n"); } } } catch
		 * (org.springframework.dao.DataAccessException e) { sop("account not found\n");
		 * }
		 */

	}

	private static void updateAccount() {
		/*
		 * sop("id?"); String id = in.nextLine(); try {
		 * sop(accountDao.getAccountById(id) + "\n");
		 * sop("do you wish to update this record [Y/N] ?"); char choice =
		 * in.next().charAt(0); if (choice == 'y' || choice == 'Y') { sop("name ?");
		 * in.nextLine(); String name = in.nextLine(); if (accountDao.updateAccount(id,
		 * name) == 1) { sop("account updated succesfully \n"); }
		 * 
		 * }
		 * 
		 * } catch (org.springframework.dao.EmptyResultDataAccessException e) {
		 * System.out.println("Account with id=" + id + "not found"); }
		 */

	}

	private static void getAccountById() {
		/*
		 * sop("id?");
		 * 
		 * String accountId = in.nextLine();
		 * 
		 * try { sop(accountDao.getAccountById(accountId) + "\n"); }
		 * 
		 * catch (org.springframework.dao.DataAccessException e) {
		 * System.out.println("account id=" + accountId + "is not found");
		 * 
		 * }
		 */

	}

	private static void getAllAccounts() {
		/*
		 * java.util.List<spring.jdbc.bean.Account> accounts =
		 * accountDao.getAllAccount(); for (spring.bean.Account account : accounts)
		 * { System.out.println(account); }
		 */

	}

	public static String generatePin() {
		// TODO Auto-generated method stub
		String accountPin = "";
		java.util.Random random = new java.util.Random();
		int zerosDigit = (int) random.nextDouble() * 10;
		int onesDigit = (int) random.nextDouble() * 10;
		int humdredsDigit = (int) random.nextDouble() * 10;
		int thousandsDigit = (int) random.nextDouble() * 10;
		return "" + zerosDigit + onesDigit + humdredsDigit + thousandsDigit;
	}

	private static void sop(String string) {
		System.out.println(string);

	}
}
