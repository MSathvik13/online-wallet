package spring.bean;

public class Account {
	private String accountName;
	private String accountId;
	private double accountBalance;
	private String accountPin;

	public Account()// jbdc program in spring must use no-arg constrcutor
	{

	}

	public Account(String accountName, String accountId, double accountBalance, String accountPin) {
		super();
		this.accountName = accountName;
		this.accountId = accountId;
		this.accountBalance = accountBalance;
		this.accountPin = accountPin;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountPin() {
		return accountPin;
	}

	public void setAccountPin(String accountPin) {
		this.accountPin = accountPin;
	}

	@Override
	public String toString() {
		return "\nAccount Details [ Name = " + accountName + ", User ID = " + accountId + ", Wallet Balance = " + accountBalance
				+ ", Password = " + accountPin + "]";
	}

	
	
}
