package spring.dao;

public interface AccountDao {
	public int createAccount(String accountName, String accountId, double accountBalance, String accountPin)
			throws  spring.exception.InsufficientFundException;

	public java.util.List<spring.bean.Account> getAllAccounts();

	public spring.bean.Account getAccountById(String accountId) throws spring.exception.AccountNotFoundException;

	public spring.bean.Account updateAccount(String accountId, String accountName)
			throws spring.exception.AccountNotFoundException;

	public boolean deleteAccount(String accountId) throws spring.exception.AccountNotFoundException;

}

