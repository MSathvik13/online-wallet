package spring.dao;


import spring.dao.AccountDao;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import spring.bean.Account;
import spring.exception.AccountNotFoundException;

public class AccountDaoImpl implements AccountDao {
	JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		// TODO Auto-generated method stub

	}

	public int createAccount(String accountName, String accountId, double accountBalance, String accountPin)
			throws spring.exception.InsufficientFundException {
		if(accountBalance < 500) {
			throw new spring.exception.InsufficientFundException("Please deposit minimum balance of Rs.500");
		}
		String sql = "insert into account values('" + accountName + "','" + accountId + "','" + accountBalance + "',"
				+ accountPin + "')";
		
		return jdbcTemplate.update(sql);

	}



	

	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	public Account getAccountById(String accountId) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public Account updateAccount(String accountId, String accountName) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteAccount(String accountId) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

}
