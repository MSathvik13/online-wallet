package spring.exception;

public class AccountTypeMisMatchException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountTypeMisMatchException(String message)
	{
		super(message);
	}

}
